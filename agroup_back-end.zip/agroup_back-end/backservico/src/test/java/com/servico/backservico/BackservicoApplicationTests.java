package com.servico.backservico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackservicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
